module.exports = {
    ProductModel: require('./Product'),
}