
module.exports = {
    shopping: require('./shopping'),
    appEvent: require('./app-event')
}
